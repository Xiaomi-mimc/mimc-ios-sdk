//
//  MIMCRtsDataType.h
//  MMCSDK
//
//  Created by zhangdan on 2018/10/6.
//  Copyright © 2018年 mimc. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum _RtsDataType {
    AUDIO,
    VIDEO
} RtsDataType;

@interface MIMCRtsDataType : NSObject

@end
