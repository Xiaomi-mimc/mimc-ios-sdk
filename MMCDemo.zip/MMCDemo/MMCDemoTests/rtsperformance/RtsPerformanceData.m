//
//  RtsPerformanceData.m
//  MIMCTest
//
//  Created by zhangdan on 2018/9/21.
//  Copyright © 2018年 mimc. All rights reserved.
//

#import "RtsPerformanceData.h"

@interface RtsPerformanceData()
@property(nonatomic) NSData *dataByte;
@property(nonatomic) int64_t dataTime;
@property(nonatomic) int64_t loginTime1;
@property(nonatomic) int64_t loginTime2;
@property(nonatomic) int64_t diaCallTime;
@property(nonatomic) int64_t recvDataTime;
@end

@implementation RtsPerformanceData

- (id)initWithDataByte:(NSData *)dataByte dataTime:(int64_t)dataTime {
    if (self = [super init]) {
        self.dataByte = dataByte;
        self.dataTime = dataTime;
    }
    return self;
}

- (id)initWithLoginTime1:(int64_t)loginTime1 loginTime2:(int64_t)loginTime2 diaCallTime:(int64_t)diaCallTime recvDataTime:(int64_t)recvDataTime {
    if (self = [super init]) {
        self.loginTime1 = loginTime1;
        self.loginTime2 = loginTime2;
        self.diaCallTime = diaCallTime;
        self.recvDataTime = recvDataTime;
    }
    return self;
}

- (NSData *)getData {
    return self.dataByte;
}

- (int64_t)getDataTime {
    return self.dataTime;
}

- (int64_t)getLoginTime1 {
    return self.loginTime1;
}

- (int64_t)getLoginTime2 {
    return self.loginTime2;
}

- (int64_t)getDiaCallTime {
    return self.diaCallTime;
}

- (int64_t)getRecvDataTime {
    return self.recvDataTime;
}
@end
