//
//  RtsPerformanceData.h
//  MIMCTest
//
//  Created by zhangdan on 2018/9/21.
//  Copyright © 2018年 mimc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RtsPerformanceData : NSObject
- (id)initWithDataByte:(NSData *)dataByte dataTime:(int64_t)dataTime;
- (id)initWithLoginTime1:(int64_t)loginTime1 loginTime2:(int64_t)loginTime2 diaCallTime:(int64_t)diaCallTime recvDataTime:(int64_t)recvDataTime;

- (NSData *)getData;
- (int64_t)getDataTime;
- (int64_t)getLoginTime1;
- (int64_t)getLoginTime2;
- (int64_t)getDiaCallTime;
- (int64_t)getRecvDataTime;
@end
