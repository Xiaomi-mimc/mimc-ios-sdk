//
//  RtsPerformanceHandler.h
//  MIMCTest
//
//  Created by zhangdan on 2018/9/21.
//  Copyright © 2018年 mimc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MCUser.h"
#import "MIMCLaunchedResponse.h"
#import "RtsMessageData.h"
#import "MCQueue.h"
#import "MIMCThreadSafeDic.h"
#import "MIMCRtsDataType.h"
#import "MIMCRtsChannelType.h"

@interface RtsPerformanceHandler : NSObject<rTSCallEventDelegate>
- (id)init;

- (MIMCLaunchedResponse *)onLaunched:(NSString *)fromAccount fromResource:(NSString *)fromResource chatId:(int64_t)chatId appContent:(NSData *)appContent;
- (void)onAnswered:(int64_t)chatId accepted:(Boolean)accepted errmsg:(NSString *)errmsg; // 会话接通之后的回调
- (void)onClosed:(int64_t)chatId errmsg:(NSString *)errmsg; // 会话被关闭的回调
- (void)handleData:(int64_t)chatId data:(NSData *)data dataType:(RtsDataType)dataType channelType:(RtsChannelType)channelType; // 接收到数据的回调

- (RtsMessageData *)pollInviteRequest:(int64_t)timeout;
- (RtsMessageData *)pollCreateResponse:(int64_t)timeout;
- (RtsMessageData *)pollBye:(int64_t)timeout;
- (MIMCThreadSafeDic *)pollDataInfo;
- (int)getMsgSize:(int)msgType;
- (Boolean)clear;
@end
