//
//  RtsPerformanceHandler.m
//  MIMCTest
//
//  Created by zhangdan on 2018/9/21.
//  Copyright © 2018年 mimc. All rights reserved.
//

#import "RtsPerformanceHandler.h"
#import "RtsPerformanceData.h"

@interface RtsPerformanceHandler()
@property(nonatomic, strong) MCQueue *inviteRequests;
@property(nonatomic, strong) MCQueue *createResponses;
@property(nonatomic, strong) MCQueue *byes;
@property(nonatomic, strong) MIMCThreadSafeDic *recvDatas;

- (int)byteArrayToInt:(NSData *)b;
@end

@implementation RtsPerformanceHandler
- (id)init {
    if (self = [super init]) {
        self.inviteRequests = [[MCQueue alloc] init];
        self.createResponses = [[MCQueue alloc] init];
        self.byes = [[MCQueue alloc] init];
        self.recvDatas = [[MIMCThreadSafeDic alloc] init];
    }
    return self;
}

- (MIMCLaunchedResponse *)onLaunched:(NSString *)fromAccount fromResource:(NSString *)fromResource chatId:(int64_t)chatId appContent:(NSData *)appContent {
    NSLog(@"onLaunched, fromAccount=%@, fromResource=%@, chatId=%lld, appContent=%@", fromAccount, fromResource, chatId, appContent);
    
    NSLog(@"onLaunched, before push: _inviteRequests.size=%d", self.inviteRequests.size);
    [self.inviteRequests push:[[RtsMessageData alloc] initWithFromAccount:fromAccount fromResource:fromResource chatId:chatId appContent:appContent]];
    NSLog(@"onLaunched, after push: _inviteRequests.size=%d", self.inviteRequests.size);
    
    return [[MIMCLaunchedResponse alloc] initWithAccepted:true msg:@"LAUNCH_OK"];
}

- (void)onAnswered:(int64_t)chatId accepted:(Boolean)accepted errmsg:(NSString *)errmsg {
    NSLog(@"onAnswered, chatId=%lld, accepted=%d, errmsg=%@", chatId, accepted, errmsg);
    
    NSLog(@"onAnswered, before push: _createResponses.size=%d", self.createResponses.size);
    [self.createResponses push:[[RtsMessageData alloc] initWithChatId:chatId accepted:accepted extraMsg:errmsg]];
    NSLog(@"onAnswered, after push: _createResponses.size=%d", self.createResponses.size);
}

- (void)onClosed:(int64_t)chatId errmsg:(NSString *)errmsg {
    NSLog(@"onClosed, chatId=%lld, errmsg=%@", chatId, errmsg);
    
    NSLog(@"onClosed, before push: _byes.size=%d", self.byes.size);
    [self.byes push:[[RtsMessageData alloc] initWithChatId:chatId extraMsg:errmsg]];
    NSLog(@"onClosed, after push: _byes.size=%d", self.byes.size);
}

- (void)handleData:(int64_t)chatId data:(NSData *)data dataType:(RtsDataType)dataType channelType:(RtsChannelType)channelType {
    NSLog(@"handleData, chatId=%lld, dataType=%d, channelType=%d", chatId, dataType, channelType);
    
    int dataId = [self byteArrayToInt:data];
    [self.recvDatas put:[[NSNumber numberWithInt:dataId] stringValue] value:[[RtsPerformanceData alloc] initWithDataByte:data dataTime:[[NSDate date] timeIntervalSince1970]*1000]];
}

- (RtsMessageData *)pollInviteRequest:(int64_t)timeout {
    @try {
        RtsMessageData *rtsMessageData = [self.inviteRequests pop:timeout];
        NSLog(@"pollInviteRequest, rtsMessageData=%@", rtsMessageData);
        return rtsMessageData;
    } @catch (NSException * ex) {
        NSLog(@"pollInviteRequest, Exception: %@, %@", ex.name, ex.reason);
        return nil;
    }
}

- (RtsMessageData *)pollCreateResponse:(int64_t)timeout {
    @try {
        RtsMessageData *rtsMessageData = [self.createResponses pop:timeout];
        NSLog(@"pollCreateResponse, rtsMessageData=%@", rtsMessageData);
        return rtsMessageData;
    } @catch (NSException * ex) {
        NSLog(@"pollCreateResponse, Exception: %@, %@", ex.name, ex.reason);
        return nil;
    }
}

- (RtsMessageData *)pollBye:(int64_t)timeout {
    @try {
        NSLog(@"pollBye, before poll bye_size=%d", self.byes.size);
        RtsMessageData *rtsMessageData = [self.byes pop:timeout];
        NSLog(@"pollBye, after poll bye_size=%d", self.byes.size);
        
        if (self.byes != nil && self.byes.size != 0) {
            RtsMessageData *rtsMessageData2 = [self.byes pop:timeout];
            NSLog(@"pollBye, chatId=%lld", rtsMessageData2.getChatId);
        }
        NSLog(@"pollBye, rtsMessageData=%@", rtsMessageData);
        return rtsMessageData;
    } @catch (NSException * ex) {
        NSLog(@"pollBye, Exception: %@, %@", ex.name, ex.reason);
        return nil;
    }
}

- (MIMCThreadSafeDic *)pollDataInfo {
    @try {
        NSLog(@"pollDataInfo, data.size=%d", self.recvDatas.getCount);
        return self.recvDatas;
    } @catch (NSException * ex) {
        NSLog(@"pollDataInfo, Exception: %@, %@", ex.name, ex.reason);
        return nil;
    }
}

- (int)getMsgSize:(int)msgType {
    int size = -1;
    
    switch (msgType) {
        case 1: size = self.inviteRequests.size; break;
        case 2: size = self.createResponses.size; break;
        case 3: size = self.byes.size; break;
        case 4: size = self.recvDatas.getCount; break;
        default: break;
    }
    
    return size;
}

- (int)byteArrayToInt:(NSData *)b {
    char *bStr = (char *)[b bytes];
    
    return (bStr[3] & 0xFF) | (bStr[2] & 0xFF) << 8 | (bStr[1] & 0xFF) << 16 | (bStr[0] & 0xFF) << 24;
}

- (Boolean)clear {
    [self.inviteRequests clear];
    [self.createResponses clear];
    [self.byes clear];
    [self.recvDatas.getDic removeAllObjects];
    return true;
}
@end
