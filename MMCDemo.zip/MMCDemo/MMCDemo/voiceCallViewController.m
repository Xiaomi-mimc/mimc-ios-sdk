//
//  voiceCallViewController.m
//  MMCDemo
//
//  Created by zhangdan on 2018/7/31.
//  Copyright © 2018年 mimc. All rights reserved.
//

#import "voiceCallViewController.h"

#define MAINVIEW_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define MAINVIEW_WIDTH ([[UIScreen mainScreen] bounds].size.width)

@interface voiceCallViewController()

@end

@implementation voiceCallViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor lightGrayColor];
    self.view.frame = CGRectMake(0, 0, MAINVIEW_WIDTH, MAINVIEW_HEIGHT);
    
    [self showVoiceCallInfo];
}

- (void)showVoiceCallInfo {
    UILabel *receiverLabel = [[UILabel alloc] initWithFrame:CGRectMake(120, 100, 70, 30)];
    receiverLabel.text = @"接收人：";
    receiverLabel.textAlignment = NSTextAlignmentRight;
    
    UILabel *receiverNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(190, 100, 70, 30)];
    [receiverNameLabel setFont:[UIFont systemFontOfSize:20]];
    [receiverNameLabel setTextColor:[UIColor purpleColor]];
    receiverNameLabel.text = self.receiver;
    
    UILabel *audioConnStateLabel = [[UILabel alloc] initWithFrame:CGRectMake(129, 130, 100, 30)];
    [audioConnStateLabel setFont:[UIFont systemFontOfSize:15]];
    [audioConnStateLabel setTextColor:[UIColor yellowColor]];
    audioConnStateLabel.text = self.audioConnState;
    
    UIButton *hangUpButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    hangUpButton.frame = CGRectMake(100, 500, 200, 30);
    hangUpButton.backgroundColor = [UIColor orangeColor];
    [hangUpButton setTitle:@"挂断" forState:UIControlStateNormal];
    [hangUpButton.titleLabel setFont:[UIFont systemFontOfSize:18]];
    [hangUpButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [hangUpButton addTarget:self action:@selector(hangUp) forControlEvents:UIControlEventTouchDown];
    
    [self.view addSubview:receiverLabel];
    [self.view addSubview:receiverNameLabel];
    [self.view addSubview:audioConnStateLabel];
    [self.view addSubview:hangUpButton];
}

- (void)hangUp {
    [self dismissViewControllerAnimated:YES completion:nil];
    [self.hangUpDelegate hangUpFunc];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
