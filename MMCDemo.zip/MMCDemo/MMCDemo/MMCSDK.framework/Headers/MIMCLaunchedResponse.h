//
//  MIMCLaunchedResponse.h
//  MMCSDK
//
//  Created by zhangdan on 2018/7/19.
//  Copyright © 2018年 mimc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MIMCLaunchedResponse : NSObject

- (id)initWithAccepted:(Boolean)accepted msg:(NSString *)msg;
- (Boolean)isAccepted;
- (NSString *)getErrMsg;
@end
