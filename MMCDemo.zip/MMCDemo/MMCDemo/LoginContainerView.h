//
//  LoginContainerView.h
//  MMCDemo
//
//  Created by zhangdan on 2018/1/4.
//  Copyright © 2018年 zhangdan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XMUserManager.h"

@interface LoginContainerView : UIViewController<UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate>

@end

