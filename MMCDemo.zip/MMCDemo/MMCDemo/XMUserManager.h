//
//  XMUserManager.h
//  MMCDemo
//
//  Created by zhangdan on 2018/1/10.
//  Copyright © 2018年 zhangdan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MCUser.h"
#import "MIMCMessage.h"
#import "MIMCGroupMessage.h"
#import "MIMCRtsDataType.h"
#import "MIMCRtsChannelType.h"

@protocol showRecvMsgDelegate
- (void)showRecvMsg:(MIMCMessage *)packet user:(MCUser *)user;
@end

@protocol returnUserStatusDelegate
- (void)returnUserStatus:(MCUser *)user status:(int)status;
@end

@interface XMUserManager : NSObject<parseTokenDelegate, onlineStatusDelegate, handleMessageDelegate, rTSCallEventDelegate>

@property(nonatomic, weak) id<showRecvMsgDelegate> showRecvMsgDelegate;
@property(nonatomic, weak) id<returnUserStatusDelegate> returnUserStatusDelegate;

- (id)init;
+ (XMUserManager *)sharedInstance;
- (BOOL)userLogin;
- (BOOL)userLogout;
- (NSString *)getAppAccount;
- (void)setAppAccount:(NSString *)appAccount;
- (MCUser *)getUser;
- (void)setUser:(MCUser *)user;
- (NSString *)parseProxyServiceToken:(NSData *)proxyResult;
- (void)statusChange:(MCUser *)user status:(int)status errType:(NSString *)errType errReason:(NSString *)errReason errDescription:(NSString *)errDescription;
- (void)handleMessage:(NSArray<MIMCMessage*> *)packets user:(MCUser *)user;
- (void)handleGroupMessage:(NSArray<MIMCGroupMessage*> *)packets;
- (void)handleServerAck:(NSString *)packetId sequence:(int64_t)sequence timestamp:(int64_t)timestamp errorMsg:(NSString *)errorMsg;
- (void)handleSendMessageTimeout:(MIMCMessage *)message;
- (void)handleSendGroupMessageTimeout:(MIMCGroupMessage *)groupMessage;
- (void)handleUnlimitedGroupMessage:(MIMCGroupMessage *)mimcGroupMessage;
- (void)handleSendUnlimitedGroupMessageTimeout:(UCPacket *)ucPacket;

- (MIMCLaunchedResponse *)onLaunched:(NSString *)fromAccount fromResource:(NSString *)fromResource chatId:(int64_t)chatId appContent:(NSData *)appContent;
- (void)onAnswered:(int64_t)chatId accepted:(Boolean)accepted errmsg:(NSString *)errmsg; // 会话接通之后的回调
- (void)onClosed:(int64_t)chatId errmsg:(NSString *)errmsg; // 会话被关闭的回调
- (void)handleData:(int64_t)chatId data:(NSData *)data dataType:(RtsDataType)dataType channelType:(RtsChannelType)channelType; // 接收到数据的回调
@end
