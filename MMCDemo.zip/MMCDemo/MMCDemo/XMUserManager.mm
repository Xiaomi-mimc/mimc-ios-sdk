//
//  XMUserManager.m
//  MMCDemo
//
//  Created by zhangdan on 2018/1/10.
//  Copyright © 2018年 zhangdan. All rights reserved.
//

#import "XMUserManager.h"

/**
 * @important!!! appId/appKey/appSecret：
 * 小米开放平台(https://dev.mi.com/cosole/man/)申请
 * 信息敏感，不应存储于APP端，应存储在AppProxyService
 * appAccount:
 * APP帐号系统内唯一ID
 * 此处appId/appKey/appSecret为小米MIMC Demo所有，会在一定时间后失效
 * 请替换为APP方自己的appId/appKey/appSecret
 **/

@interface XMUserManager ()
@property(nonatomic) int64_t appId;
@property(nonatomic) NSString *appKey;
@property(nonatomic) NSString *appSecret;
@property(nonatomic) NSString *appAccount;
@property(nonatomic) NSString *url;
@property(nonatomic, strong) MCUser *user;

- (NSMutableURLRequest *)generateHttpRequest:(NSURL *)url appId:(int64_t)appId
                                      appKey:(NSString *)appKey appSecret:(NSString *)appSecret
                                  appAccount:(NSString *)appAccount;
@end

static XMUserManager *_sharedInstance = nil;

@implementation XMUserManager
@synthesize appAccount = _appAccount;
@synthesize user = _user;

+ (XMUserManager *)sharedInstance {
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        _sharedInstance = [[XMUserManager alloc] init];
    });
    return _sharedInstance;
}

- (id)init {
    /**
     * @important!!! appId/appKey/appSecret：
     * 小米开放平台(https://dev.mi.com/cosole/man/)申请
     * 信息敏感，不应存储于APP端，应存储在AppProxyService
     * 此处appId/appKey/appSecret为小米MIMC Demo所有，会在一定时间后失效
     * 请替换为APP方自己的appId/appKey/appSecret
     **/
    if (self = [super init]) {
        self.appId = 2882303761517669588L;
        self.appKey = @"5111766983588";
        self.appSecret = @"b0L3IOz/9Ob809v8H2FbVg==";
        self.url = @"https://mimc.chat.xiaomi.net/api/account/token";
    }
    return self;
}

- (NSMutableURLRequest *)generateHttpRequest:(NSURL *)url appId:(int64_t)appId appKey:(NSString *)appKey
                                   appSecret:(NSString *)appSecret appAccount:(NSString *)appAccount {
    /**
     * @important!!!
     * appId/appKey/appSecret：
     *     小米开放平台(https://dev.mi.com/cosole/man/)申请
     *     信息敏感，不应存储于APP端，应存储在AppProxyService
     * appAccount:
     *      APP帐号系统内唯一ID
     * AppProxyService：
     *     a) 验证appAccount合法性；
     *     b) 访问TokenService，获取Token并下发给APP；
     * !!此为Demo APP所以appId/appKey/appSecret存放于APP本地!!
     **/
    
    if (url == nil || appId == 0 || appKey == nil || appKey.length == 0 || appSecret == nil
        || appSecret.length== 0 || appAccount == nil || appAccount.length == 0) {
        NSLog(@"generateRequest, fail, parameter:url=%@, appId=%lld, appKey=%@, appKey_len=%lu, appSecret=%@, appSecret_len=%lu, appAccount=%@, appAccount_len=%lu", url, appId, appKey, (long)appKey.length, appSecret, (long)appSecret.length, appAccount, (long)appAccount.length);
        return nil;
    }
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    NSMutableDictionary *dicObj = [[NSMutableDictionary alloc] init];
    [dicObj setObject:[NSNumber numberWithLongLong:appId] forKey:@"appId"];
    [dicObj setObject:appKey forKey:@"appKey"];
    [dicObj setObject:appSecret forKey:@"appSecret"];
    [dicObj setObject:appAccount forKey:@"appAccount"];
    
    NSData *dicData = [NSJSONSerialization dataWithJSONObject:dicObj options:NSJSONWritingPrettyPrinted error:nil];
    if (dicData == nil || dicData.length == 0) {
        NSLog(@"generateRequest, dicData is nil");
        return nil;
    }
    
    [request setHTTPMethod:@"POST"];
    [request setValue:[NSString stringWithFormat:@"application/json"] forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:dicData];
    return request;
}

- (BOOL)userLogin {
    NSURL *url = [NSURL URLWithString:_url];
    NSMutableURLRequest *request = [self generateHttpRequest:url appId:_appId appKey:_appKey appSecret:_appSecret appAccount:_appAccount];
    if (request == nil) {
        NSLog(@"userLogin, request is nil");
        return false;
    }
    
    _user = [[MCUser alloc] initWithAppAccount:_appAccount andAsynchFetchTokenRequest:request];
    _user.parseTokenDelegate = self;
    _user.onlineStatusDelegate = self;
    _user.handleMessageDelegate = self;
    _user.rTSCallEventDelegate = self;
    
    return [_user login];
}

- (BOOL)userLogout {
    return [_user logout];
}

- (NSString *)parseProxyServiceToken:(NSData *)proxyResult {
    if (proxyResult == nil) {
        NSLog(@"parseToken, result is nil");
        return nil;
    }

    return [[NSString alloc] initWithData:proxyResult encoding:NSUTF8StringEncoding];
}

- (void)statusChange:(MCUser *)user status:(int)status errType:(NSString *)errType errReason:(NSString *)errReason errDescription:(NSString *)errDescription {
    if (user == nil) {
        NSLog(@"statusChange, user is nil");
        return;
    }
    [self.returnUserStatusDelegate returnUserStatus:user status:status];
    NSLog(@"statusChange, Called, uuid=%@, user=%@, status=%d, errType=%@, errReason=%@, errDescription=%@",user.getUuid, user, status, errType, errReason, errDescription);
}


- (void)handleMessage:(NSArray<MIMCMessage*> *)packets user:(MCUser *)user {
    for (MIMCMessage *p in packets) {
        if (p == nil) {
            NSLog(@"handleMessage, ReceiveMessage, P2P is nil");
            continue;
        }
        NSLog(@"handleMessage, ReceiveMessage, P2P, {%@}-->{%@}, packetId=%@, payload=%@", p.getFromAccount, user.getAppAccount, p.getPacketId, p.getPayload);
        
        [self.showRecvMsgDelegate showRecvMsg:p user:user];
    }
}

- (void)handleGroupMessage:(NSArray<MIMCGroupMessage*> *)packets {
    NSLog(@"handleGroupMessage, Called");
}

- (void)handleServerAck:(NSString *)packetId sequence:(int64_t)sequence timestamp:(int64_t)timestamp errorMsg:(NSString *)errorMsg {
    NSLog(@"handleServerAck, ReceiveMessageAck, ackPacketId=%@, sequence=%lld, timestamp=%lld, errorMsg=%@", packetId, sequence, timestamp, errorMsg);
}

- (void)handleSendMessageTimeout:(MIMCMessage *)message {
    NSLog(@"handleSendMessageTimeout, message.packetId=%@, message.sequence=%lld, message.timestamp=%lld, message.fromAccount=%@, message.toAccount=%@, message.payload=%@", message.getPacketId, message.getSequence, message.getTimestamp, message.getFromAccount, message.getToAccount, message.getPayload);
}

- (void)handleSendGroupMessageTimeout:(MIMCGroupMessage *)groupMessage {
    NSLog(@"handleSendGroupMessageTimeout, groupMessag.packetId=%@, groupMessag.sequence=%lld, groupMessage.timestamp=%lld, groupMessage.fromAccount=%@, groupMessage.groupId=%lld, groupMessag.payload=%@", groupMessage.getPacketId, groupMessage.getSequence, groupMessage.getTimestamp, groupMessage.getFromAccount, groupMessage.getGroupId, groupMessage.getPayload);
}

- (void)handleUnlimitedGroupMessage:(MIMCGroupMessage *)mimcGroupMessage {
    NSLog(@"handleUnlimitedGroupMessage, receive unlimitedGroupMessage packet, packetId=%@, sequence=%lld, timestamp=%lld, fromAccount=%@, groupId=%lld, payload=%@", mimcGroupMessage.getPacketId, mimcGroupMessage.getSequence, mimcGroupMessage.getTimestamp, mimcGroupMessage.getFromAccount, mimcGroupMessage.getGroupId, mimcGroupMessage.getPayload);
}

- (void)handleSendUnlimitedGroupMessageTimeout:(UCPacket *)ucPacket {
    NSLog(@"handleSendUnlimitedGroupMessageTimeout, ucPacket=%@", ucPacket);
}

- (MIMCLaunchedResponse *)onLaunched:(NSString *)fromAccount fromResource:(NSString *)fromResource chatId:(int64_t)chatId appContent:(NSData *)appContent {
    NSLog(@"onLaunched, fromAccount=%@, fromResource=%@, chatId=%lld, appContent=%@", fromAccount, fromResource, chatId, appContent);
    
    return [[MIMCLaunchedResponse alloc] initWithAccepted:true msg:@"LAUNCH_OK"];
}

- (void)onAnswered:(int64_t)chatId accepted:(Boolean)accepted errmsg:(NSString *)errmsg {
    NSLog(@"onAnswered, chatId=%lld, accepted=%d, errmsg=%@", chatId, accepted, errmsg);
}

- (void)onClosed:(int64_t)chatId errmsg:(NSString *)errmsg {
    NSLog(@"onClosed, chatId=%lld, errmsg=%@", chatId, errmsg);
}

- (void)handleData:(int64_t)chatId data:(NSData *)data dataType:(RtsDataType)dataType channelType:(RtsChannelType)channelType {
    NSLog(@"handleData, chatId=%lld, data=%@, dataType=%d, channelType=%d", chatId, data, dataType, channelType);
    
    if ([self.user sendRtsData:chatId data:data dataType:AUDIO dataPriority:MIMC_P0 canBeDropped:true resendCount:0 channelType:RELAY context:NULL]) {
        NSLog(@"handleData, sendRtsData success");
        return;
    }
    NSLog(@"handleData, sendRtsData fail");
}

- (void)handleSendDataSuccess:(int64_t)chatId groupId:(int)groupId context:(void *)context {
    
}

- (void)handleSendDataFail:(int64_t)chatId groupId:(int)groupId context:(void *)context {
    
}

- (NSString *)getAppAccount {
    return self.appAccount;
}

- (void)setAppAccount:(NSString *)appAccount {
    _appAccount = appAccount;
}

- (MCUser *)getUser {
    return self.user;
}

- (void)setUser:(MCUser *)user {
    _user = user;
}
@end
